# Foster Data Pro

This is the first static prototype for Foster Data Pro.

## Current stage
- Responsive homepage
- Data, Airtime, Cable TV and Electricity service cards
- Demo buttons
- Mobile-friendly design
- No real payment or VTU transactions yet

## Next development stages
1. Customer registration/login
2. Customer dashboard
3. VTU provider/API integration
4. Payment gateway integration
5. Transaction history
6. Admin dashboard
7. Security, testing and launch

Do not put API keys, passwords, payment secrets or other private credentials in this static website.
